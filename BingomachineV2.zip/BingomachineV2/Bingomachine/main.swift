//
//  main.swift
//  Bingomachine
//
//  Created by Toyosi Oyinloye on 14/11/2023.
//

import Foundation

var bingoMachine = BingoMachine ()
while bingoMachine.ballsRemaining() {
    print(bingoMachine.getNumber()!)
    print(", ")
    let luckyNumber  = 7;
    if bingoMachine.hasCalled(number: luckyNumber) {
        print("Lucky number \(luckyNumber) found")
        break
    }
}
