//
//  BingoMachine.swift
//  Bingomachine
//
//  Created by Toyosi Oyinloye on 14/11/2023.
// Editied by Toyosi Oyinloye on 20/11/2024

import Foundation
class BingoMachine {
    private var tumbler: [Int]
    var calledNumbers: [Int]
    
    init() {
        tumbler = [Int] ()
        calledNumbers = [Int] ()
        //add balls to the tumbler
        for i in 1...90 {
            tumbler.append(i)
        }
        
    }
    
    func getNumber() -> Int? {
        // Check if tumbler is not empty
        guard !tumbler.isEmpty else {
            print("Tumbler is empty")
            return nil
        }
        
        // Select a random index and remove the number at that index
        let randomIndex = tumbler.indices.randomElement()!
        let randomNumber = tumbler.remove(at: randomIndex)
        
        // Append the number to calledNumbers
        calledNumbers.append(randomNumber)
        
        return randomNumber
    }
    func ballsRemaining() -> Bool {
        return tumbler.count > 0
    }
    func hasCalled (number: Int) -> Bool {
        return calledNumbers.contains(number)
    }
}
